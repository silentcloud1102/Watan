export resType;
export playerColor;

enum class resType{
    CAFFEINE = 0,
    LAB = 1,
    LECTURE = 2,
    STUDY = 3,
    TUTORIAL = 4,
    NETFLIX = 5
};

enum class playerColor{
    BLUE = 0, 
    RED = 1, 
    ORANGE = 2, 
    YELLOW = 3
};
