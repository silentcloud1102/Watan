module Goal;

import <string>;
import <vector>;
import Resource;
import IObserver;
import ISubject;

// DECLARING THE CONSTANT
const Resource Goal::resource_cost{0, 0, 0, 1, 1};

// CONSTRUCTOR
Goal::Goal(int location, bool colour): ISubject(location), colour{colour} {}

// GET METHODS
std::string Goal::get_num(bool format) const {
    if (owner) {
        std::string format_str;
        std::string end_str;
        if(format && colour){
            format_str = owner->colour();
            end_str = "\033[0m";
        }
        return format_str + owner->get_name()[0] + "A" + end_str;
    }

    // else no owner
    if (location < 10) {
        return " " + std::to_string(location);
    
    }
    return std::to_string(location);
}


// Subscription Method
void Goal::acquire(IObserver* student){
    // set owner to student pointer
    owner = student;
}

// ADJACENCY LOGIC METHODS: subject to change

void Goal::set_adjacent_criteria(const std::vector<int> & criteria) { 
    adjacent_criteria = criteria; 
}

void Goal::set_adjacent_goals(const std::vector<int> & goals) { 
    adjacent_goals = goals; 
}

// BUY LOGIC METHODS:

// checks for ownership used by student
bool Goal::owned() const{
    return owner != nullptr;
}

// returns the eligibility of the goal based on adjacent goals/criteria
bool Goal::adjacent_check(std::vector<int> &criteria, std::vector<int> &goals) const{
    // check that there is adjacent Criteria already completed
    for (auto adj = adjacent_criteria.begin(); adj != adjacent_criteria.end(); ++adj) {
        for(auto other = criteria.begin(); other != criteria.end(); ++other){
            if(*other == *adj){
                // if there is an adjacent completed criteria, we can complete the goal
                return true;
            }
        }
    }

    // check for adjacent goals achieved
    for (auto adj = adjacent_goals.begin(); adj != adjacent_goals.end(); ++adj) {
        for(auto other = goals.begin(); other != goals.end(); ++other){
            if(*other == *adj){
                // if there is an adjacent completed goal
                // then we can complete this goal
                return true;
            }
        }
    }
    return false;
}

// returns the cost in Resource
const Resource & Goal::cost() const {
    return resource_cost;
}

// Save method for saves
std::string Goal::get_save_string() const{
    return std::to_string(location);
}
